let v =  15;
number=document.querySelector(".number");

const arr = [];
for (let i = 0; i < v; i++) {
    arr[i] = i;
}


// creation

function showbars() {
    let section = document.querySelector("section")
    section.innerHTML = ''; //clear existing
    for (let i = 0; i < v; i++) {
        
        const bar = document.createElement("div")
        bar.style.width = "15%";
        bar.style.height = arr[i] *(100/v) + "%";
        
        bar.classList.add("bars")
        section.append(bar)
    }
}

// unsorting
unsortbar(arr);
async function unsort(arr) {
    // Fisher-Yates (Knuth) shuffle algorithm
    for (let i = 0; i < v; i++) {
        const j = Math.floor(Math.random() *v ); 
        [arr[i], arr[j]] = [arr[j], arr[i]];
        if(arr[j]==0 || arr[i]==0){
            arr[j]=v;   
        }
    }
    showbars(); // Show bars after unsorting
}





// Function to perform quicksort
async function quickSort(arr, low, high) {
    if (low < high) {
        // Partition the array and get the pivot index
        let pivotIndex = await partition(arr, low, high);

        // Recursively sort the sub-arrays before and after the pivot
        await quickSort(arr, low, pivotIndex - 1);
        await quickSort(arr, pivotIndex + 1, high);
    }
}

// Function to partition the array
async function partition(arr, low, high) {
    let pivot = arr[high]; // Choose the pivot element (here, we choose the last element)
    let i = low - 1; // Initialize the index of the smaller element

    for (let j = low; j < high; j++) {
        // If the current element is smaller than the pivot
        if (arr[j] < pivot) {
            i++; // Increment index of smaller element
            await swap(arr, i, j); // Swap arr[i] and arr[j]
        }
    }
    
    await swap(arr, i + 1, high); // Swap arr[i + 1] and arr[high], to place pivot at its correct position
    return i + 1; // Return the pivot index
}

// Function to swap two elements in an array
// Function to swap two elements in an array and update visual representation
async function swap(arr, i, j) {
    let temp = arr[i];
    arr[i] = arr[j];
    arr[j] = temp;

    // Swap bars visually
    const bars = document.querySelectorAll(".bars");
    const bar1 = bars[i];
    const bar2 = bars[j];

    // Add transition class for animation
    bar1.classList.add("transition");
    bar2.classList.add("transition");
    bar1.style.backgroundColor = "green";
    bar2.style.backgroundColor = "red";

    // Swap heights
    let tempHeight = bar1.style.height;
    bar1.style.height = bar2.style.height;
    bar2.style.height = tempHeight;

    // Change colors to indicate swapping
    bar1.style.backgroundColor = "red";
    bar2.style.backgroundColor = "green";

    // Play sound effect
    playSound();

    // Wait for animation to complete
    await sleep(0.2);

    // Restore colors
    bar1.style.backgroundColor = "whitesmoke";
    bar2.style.backgroundColor = "whitesmoke";

    // Remove transition class
    bar1.classList.remove("transition");
    bar2.classList.remove("transition");
}




const melodyNotes = [
    440, // A4
    493.88, // B4
    523.25, // C5
    587.33, // D5
    659.25, // E5
    698.46, // F5    
];

let currentNoteIndex = 0;

function playSound() {
    const audioContext = new (window.AudioContext || window.webkitAudioContext)();
    const oscillator = audioContext.createOscillator();
    const gainNode = audioContext.createGain();
    oscillator.connect(gainNode);
    gainNode.connect(audioContext.destination);
    oscillator.type = "sine"; // Sine wave
    oscillator.frequency.value = melodyNotes[currentNoteIndex % melodyNotes.length]; // Play the next note in the melody
    gainNode.gain.value = 0.8; // Volume
    oscillator.start();
    setTimeout(function () {
        oscillator.stop();
    }, 150); // Adjust duration of each note (200ms for example)

    currentNoteIndex++;
}




function sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, 900));
}

async function unsortbar() {
    unsort(arr);
}

async function check(){
    let bars=document.querySelectorAll(".bars")
    for(let i=0;i<bars.length;i++){
        bars[i].style.backgroundColor="green"
        await sleep(0.1);
        playSound();
        bars[i].style.backgroundColor="whitesmoke"
    }
}

async function sortbar() {
    await quickSort(arr, 0, v - 1); // Call quickSort directly
    showbars()
    check()
    console.log("Sorted Array:", arr); // Output sorted array
}


// assigning to button
const unsorting = document.querySelector(".Unsort");
unsorting.addEventListener("click", unsortbar);

const Sort = document.querySelector(".sort");
Sort.addEventListener("click", sortbar);
const Home=documet.querySelector(".")
console.log(arr)
